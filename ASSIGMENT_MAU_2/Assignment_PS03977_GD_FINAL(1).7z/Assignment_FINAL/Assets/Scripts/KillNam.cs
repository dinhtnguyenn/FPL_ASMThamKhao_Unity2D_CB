﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillNam : MonoBehaviour {
	private Animator anim;
	// Use this for initialization
	void Start () {
		anim = GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnTriggerEnter2D(Collider2D other){
		anim.SetBool ("die", true);
		//yield return new WaitForSeconds (3);
		Destroy (gameObject);
	}
}
