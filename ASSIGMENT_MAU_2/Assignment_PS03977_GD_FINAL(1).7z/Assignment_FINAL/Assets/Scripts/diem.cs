﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class diem : MonoBehaviour {

	public Text scoreText;
	public static int score = 0;
	// Use this for initialization
	void Start () {
		scoreText = GetComponent<Text> ();
	}

	// Update is called once per frame
	void Update () {
		scoreText.text = "Score: " + score;
	}
}
