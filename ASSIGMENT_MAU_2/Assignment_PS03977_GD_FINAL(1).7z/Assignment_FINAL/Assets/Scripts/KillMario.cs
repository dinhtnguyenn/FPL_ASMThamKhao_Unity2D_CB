﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillMario : MonoBehaviour {
	public Mario  mario;
	public	GameObject gameObject;
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnTriggerEnter2D(Collider2D other){
		if (other.gameObject.tag == "kill_mario") {
			Destroy (other.gameObject);
			GameObject.Find ("mario_die").GetComponent<AudioSource> ().Play ();
			gameObject.SetActive (true);

		}
	}
}
