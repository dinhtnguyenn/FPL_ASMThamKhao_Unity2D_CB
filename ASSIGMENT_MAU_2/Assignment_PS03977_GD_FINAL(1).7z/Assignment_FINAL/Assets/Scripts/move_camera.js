﻿#pragma strict

var mario : Transform;


function Update () {
	transform.position = new Vector3 (mario.position.x, transform.position.y, transform.position.z);
}
