﻿#pragma strict

function Start () {
	
}

function Update () {
	
}
function OnTriggerEnter2D(other : Collider2D){

		gameObject.Find("coin").GetComponent.<AudioSource>().Play ();
		Destroy (gameObject);
		//diem.score++;
}