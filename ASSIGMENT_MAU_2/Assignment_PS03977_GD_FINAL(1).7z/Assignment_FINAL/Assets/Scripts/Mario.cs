﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mario : MonoBehaviour {

	public float upForce = 300f;
	private Rigidbody2D rb2d;
	bool facingRight = true;
	public float maxSpeed = 10f;
	private Animator anim;
	public bool isDead = false;

	// Use this for initialization
	void Start () {
		rb2d = GetComponent<Rigidbody2D> ();
		anim = GetComponent<Animator> ();
	}

	// Update is called once per frame
	void Update () {
		float move = Input.GetAxis ("Horizontal");
		rb2d.velocity = new Vector2 (move * maxSpeed, rb2d.velocity.y);

		if(Input.GetKey(KeyCode.UpArrow))
		{
			rb2d.velocity = Vector2.zero;
			rb2d.AddForce (new Vector2 (0, upForce));
			anim.SetTrigger ("mario_jump");
			GameObject.Find ("jump_small").GetComponent<AudioSource> ().Play ();
		}
		if(Input.GetKey(KeyCode.LeftArrow)){
			anim.SetTrigger ("mario_run");
		}
		if(Input.GetKey(KeyCode.RightArrow)){
			anim.SetTrigger ("mario_run");
		}
	}
	void Flip(){
		facingRight = !facingRight;
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;

	}

}
